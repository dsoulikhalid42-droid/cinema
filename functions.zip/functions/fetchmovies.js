export async function onRequest(context) {
  const { searchParams } = new URL(context.request.url);
  const endpoint = searchParams.get('endpoint');
  
  if (!endpoint) {
    return new Response(JSON.stringify({ error: "Missing endpoint" }), { status: 400 });
  }

  // هنا غانقراو الـ API KEY بطريقة آمنة من سيرفرات Cloudflare مباشرة
  const TMDB_API_KEY = context.env.TMDB_API_KEY; 

  // بناء الرابط لـ TMDB مع تمرير باقي البارامترات بحال الـ query ديال البحث
  const url = new URL(`https://api.themoviedb.org/3/${endpoint}`);
  url.searchParams.set('api_key', TMDB_API_KEY);
  
  for (const [key, value] of searchParams.entries()) {
    if (key !== 'endpoint') {
      url.searchParams.set(key, value);
    }
  }

  try {
    const response = await fetch(url.toString());
    const data = await response.json();
    
    return new Response(JSON.stringify(data), {
      headers: { 
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*" 
      }
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: "Failed to fetch from TMDB" }), { status: 500 });
  }
}
